﻿using System.Net;
using MobyLabWebProgramming.Core.Constants;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;
using MobyLabWebProgramming.Core.Errors;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;
using MobyLabWebProgramming.Core.Specifications;
using MobyLabWebProgramming.Infrastructure.Database;
using MobyLabWebProgramming.Infrastructure.Repositories.Interfaces;
using MobyLabWebProgramming.Infrastructure.Services.Interfaces;

namespace MobyLabWebProgramming.Infrastructure.Services.Implementations;

public class SongService : ISongService
{
    private readonly IRepository<WebAppDatabaseContext> _repository;
    private readonly ILoginService _loginService;
    private readonly IMailService _mailService;

    /// <summary>
    /// Inject the required services through the constructor.
    /// </summary>
    public SongService(IRepository<WebAppDatabaseContext> repository, ILoginService loginService, IMailService mailService)
    {
        _repository = repository;
        _loginService = loginService;
        _mailService = mailService;
    }

    public async Task<ServiceResponse<SongDTO>> GetSong(Guid id, CancellationToken cancellationToken = default)
    {
        var result = await _repository.GetAsync(new UserProjectionSpec(id), cancellationToken); // Get a user using a specification on the repository.

        return result != null ? 
            ServiceResponse<UserDTO>.ForSuccess(result) : 
            ServiceResponse<UserDTO>.FromError(CommonErrors.UserNotFound); // Pack the result or error into a ServiceResponse.
    }

    public async Task<ServiceResponse<PagedResponse<SongDTO>>> GetSongs(PaginationSearchQueryParams pagination, CancellationToken cancellationToken = default)
    {
        var result = await _repository.PageAsync(pagination, new SongProjectionSpec(pagination.Search), cancellationToken); // Use the specification and pagination API to get only some entities from the database.

        return ServiceResponse<PagedResponse<SongDTO>>.ForSuccess(result);
    }

    public async Task<ServiceResponse<int>> GetSongsCount(CancellationToken cancellationToken = default) => 
        ServiceResponse<int>.ForSuccess(await _repository.GetCountAsync<Song>(cancellationToken)); // Get the count of all user entities in the database.

    public async Task<ServiceResponse> AddSong(SongAddDTO song, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {
        var result = await _repository.GetAsync(new SongSpec(song.Name), cancellationToken);

        if (result != null)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Conflict, "The user already exists!", ErrorCodes.UserAlreadyExists));
        }

        await _repository.AddAsync(new Song
        {
            Name = song.Name,
            GenreId = song.GenreId,
            ArtistId = song.ArtistId,
            CreatorId = requestingUser.Id
        }, cancellationToken); // A new entity is created and persisted in the database.

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> UpdateSong(SongUpdateDTO song, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {

        var entity = await _repository.GetAsync(new SongSpec(song.Id), cancellationToken); 

        if (entity != null) // Verify if the user is not found, you cannot update an non-existing entity.
        {
            if (entity.CreatorId != requestingUser.Id)
                return ServiceResponse.FromError(CommonErrors.UnauthorizedAccess);
            entity.Name = song.Name ?? entity.Name;
            entity.ArtistId = song.ArtistId ?? entity.ArtistId;
            entity.GenreId = song.GenreId ?? entity.GenreId;
            entity.GenreId = song.GenreId ?? entity.GenreId;

            await _repository.UpdateAsync(entity, cancellationToken); // Update the entity and persist the changes.
        }

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> DeleteSong(Guid id, UserDTO? requestingUser = default, CancellationToken cancellationToken = default)
    {
        var entity = await _repository.GetAsync(new SongSpec(id), cancellationToken);

        if (entity.CreatorId != requestingUser.Id)
            return ServiceResponse.FromError(CommonErrors.UnauthorizedDelete);

        await _repository.DeleteAsync<Song>(id, cancellationToken); // Delete the entity.

        return ServiceResponse.ForSuccess();
    }
}

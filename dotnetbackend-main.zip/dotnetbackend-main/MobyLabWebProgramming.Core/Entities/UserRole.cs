﻿namespace MobyLabWebProgramming.Core.Entities;

public class UserRole : BaseEntity
{
    public string Name { get; set; } = default!;
    public ICollection<User> User { get; set; } = default!;
}

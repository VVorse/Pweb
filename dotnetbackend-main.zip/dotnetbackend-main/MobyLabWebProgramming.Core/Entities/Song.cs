﻿namespace MobyLabWebProgramming.Core.Entities;

/// <summary>
/// This is an example for a user entity, it will be mapped to a single table and each property will have it's own column except for entity object references also known as navigation properties.
/// </summary>
public class Song : BaseEntity
{
    public string Name { get; set; } = default!;
    public Artist Artist{ get; set; } = default!;
    public Genre Genre { get; set; } = default!;
    public User Creator { get; set; } = default!;

    public Guid CreatorId { get; set; } = default!;
    public Guid ArtistId { get; set; } = default!;  
    public Guid GenreId { get; set; } = default!;

    public ICollection<SongTab> SongTabs { get; set; } = default!;
}

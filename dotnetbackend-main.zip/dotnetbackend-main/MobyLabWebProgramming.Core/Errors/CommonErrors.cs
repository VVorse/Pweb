﻿using System.Net;

namespace MobyLabWebProgramming.Core.Errors;

/// <summary>
/// Common error messages that may be reused in various places in the code.
/// </summary>
public static class CommonErrors
{
    public static ErrorMessage UserNotFound => new(HttpStatusCode.NotFound, "User doesn't exist!", ErrorCodes.EntityNotFound);
    public static ErrorMessage UserRoleNotFound => new(HttpStatusCode.NotFound, "User Role doesn't exist!", ErrorCodes.EntityNotFound);
    public static ErrorMessage FileNotFound => new(HttpStatusCode.NotFound, "File not found on disk!", ErrorCodes.PhysicalFileNotFound);
    public static ErrorMessage TechnicalSupport => new(HttpStatusCode.InternalServerError, "An unknown error occurred, contact the technical support!", ErrorCodes.TechnicalError);
    public static ErrorMessage UnauthorizedAccess => new(HttpStatusCode.Unauthorized, "You don not own this song, you can't edit it!", ErrorCodes.CannotUpdate);
    public static ErrorMessage UnauthorizedDelete => new(HttpStatusCode.Unauthorized, "You don not own this song, you can't delete it!", ErrorCodes.CannotDelete);
}
